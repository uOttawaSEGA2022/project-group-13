package com.example.myapplication;

public class Suspension {



        private String lengthOfSuspension;
        private boolean temporary;
        private boolean permanent;

        public Suspension( boolean temporary, boolean permanent, String lengthOfSuspension) {

            this.lengthOfSuspension = lengthOfSuspension;
            this.temporary = temporary;
            this.permanent = permanent;
        }



        public String getLengthOfSuspension() {
            return lengthOfSuspension;
        }

        public void setLengthOfSuspension(String newLength) {
            lengthOfSuspension = newLength;
        }

        public boolean getTemporary() {
            return temporary;
        }

        public void setTemporary(boolean newTemporary) {
            temporary = newTemporary;
        }

        public boolean getPermanent() {
            return permanent;
        }

        public void setPermanent(boolean newPermanent) {
            permanent = newPermanent;
        }


    }
}

