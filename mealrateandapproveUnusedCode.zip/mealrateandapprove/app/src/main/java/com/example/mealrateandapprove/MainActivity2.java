package com.example.mealrateandapprove;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity2 extends AppCompatActivity {
    private Button welcomeButton;
    private Button rejectButton;
    private Button approveButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);



        welcomeButton = (Button)findViewById(R.id.returnWelcomeButton);
        welcomeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                returnToWelcome(v);
            }
        });

        rejectButton = (Button)findViewById(R.id.returnWelcomeButton);
        rejectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setRejected(v);

            }
        });
        approveButton = (Button)findViewById(R.id.returnWelcomeButton);
        approveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                setApproved(v);

            }
        });
    }

}