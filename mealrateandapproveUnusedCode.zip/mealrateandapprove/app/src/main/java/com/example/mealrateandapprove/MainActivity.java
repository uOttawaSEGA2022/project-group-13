package com.example.mealrateandapprove;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class PurchaseRequestPage extends AppCompatActivity implements PurchaseRequestsAdapter.RecyclerViewInterface{

    private String UID;
    private RecyclerView recyclerView;

    private PurchaseRequestsAdapter adapter;
    private ArrayList<String> list;
    private DatabaseReference ref;

    private Button welcomeButton;
    private TextView emptyRequests;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_page);

        Bundle bundle = getIntent().getExtras();
        UID = bundle.getString("UID");
        Log.d("UID Requests",UID);

        ref = FirebaseDatabase.getInstance().getReference("USERS").child(UID).child("PURCHASEREQUESTS");




        emptyRequests = (TextView) findViewById(R.id.emptyRequestTextView);
        emptyRequests.setVisibility(View.GONE);

        welcomeButton = (Button)findViewById(R.id.returnWelcomeButton);
        welcomeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                returnToWelcome(v);
            }
        });

        recyclerView = (RecyclerView) findViewById(R.id.menuRecyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        list = new ArrayList<>();
        adapter = new PurchaseRequestsAdapter(this, list,this);

        recyclerView.setAdapter(adapter);

        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot dataSnapshot: snapshot.getChildren()){
                    String[] purchaseinfo = new String[2];
                    int counter = 0;
                    for(DataSnapshot fields :dataSnapshot.getChildren()){
                        if (counter==2){break;}
                        purchaseinfo[counter] = fields.getValue().toString();
                        counter++;
                    }
                    String clientUID = purchaseinfo [0];
                    String meal = purchaseinfo [1];
                    String date = purchaseinfo [2];









                    if(list.isEmpty()){
                        emptyRequests.setVisibility(View.VISIBLE);
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }


    @Override
    public void onItemClick(int position, String ClientUID, String date, Meal meal) {
        Intent CookApprove = new Intent(getApplicationContext(),CookApprove.class);
        editMealPage.putExtra("name",meal);

        editMealPage.putExtra("UID",UID);

        startActivity(CookApprove);

    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {
        super.onPointerCaptureChanged(hasCapture);
    }

    private void returnToWelcome(View view){
        Intent returnToWelcome = new Intent(getApplicationContext(),WelcomePage.class);
        returnToWelcome.putExtra("role","COOK");
        startActivity(returnToWelcome);
    }


    }
}