package com.example.mealrateandapprove;

public class CookApprove {
}
